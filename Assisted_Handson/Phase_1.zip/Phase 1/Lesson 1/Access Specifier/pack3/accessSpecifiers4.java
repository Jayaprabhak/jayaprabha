package pack3;
import pack1.*;
public class accessSpecifiers4 extends pubaccessSpecifier{
	public static void main(String [] args) {
		accessSpecifiers4 obj = new accessSpecifiers4();
		obj.display();
	}
}