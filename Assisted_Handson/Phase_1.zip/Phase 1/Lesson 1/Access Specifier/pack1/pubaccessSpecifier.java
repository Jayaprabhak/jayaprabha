package pack1;

public class pubaccessSpecifier {
public void display() {
	System.out.println("You are using public access specifier");
}
}